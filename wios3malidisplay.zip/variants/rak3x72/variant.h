#pragma once

#include <variant_RAK3172_MODULE.h>

#undef RNG
